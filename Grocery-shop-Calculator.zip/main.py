sum = 0
while(True):
    userInput = input("Enter the Item Price or press q to quit:\n")
    if(userInput != 'q'):
        sum = sum + float(userInput)
        print(f"Your order total so far is {sum}")
    
    else:
     
      print(f"Your Bill for Total Item is {sum}. Thanks for shopping with us.")
      break